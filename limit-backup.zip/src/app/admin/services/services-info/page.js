import ServiceInfoClient from "./ServiceInfoClient";

export const metadata = { title: "Services Info | Admin" };

export default function ServicesInfoPage() {
  return <ServiceInfoClient />;
}
