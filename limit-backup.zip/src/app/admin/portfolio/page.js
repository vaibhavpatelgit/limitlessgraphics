export const metadata = { title: "Portfolio | Admin" };

export default function PortfolioPage() {
  return (
    <div>
      <h1 className="text-2xl md:text-3xl font-bold mb-4">Portfolio</h1>
      <p className="text-neutral-300">
        Placeholder — portfolio management coming soon.
      </p>
    </div>
  );
}
