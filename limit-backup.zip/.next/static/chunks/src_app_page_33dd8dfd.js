(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a62e7465._.js",
  "static/chunks/node_modules_17490194._.js",
  "static/chunks/[root-of-the-server]__b005d543._.css"
],
    source: "dynamic"
});
