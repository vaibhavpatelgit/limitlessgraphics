(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_4257aa4c._.js",
  "static/chunks/src_app_services_[slug]_service-detail_client_jsx_e806f6bc._.js"
],
    source: "dynamic"
});
