(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_de4400f2._.js",
  "static/chunks/src_components_ContactClient_jsx_a1df181c._.js"
],
    source: "dynamic"
});
