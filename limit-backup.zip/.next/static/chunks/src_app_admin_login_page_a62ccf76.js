(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_admin_login_ui_LoginForm_jsx_0c4bf828._.js"
],
    source: "dynamic"
});
