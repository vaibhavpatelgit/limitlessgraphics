(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_09436b6d._.js",
  "static/chunks/src_cc0c2db5._.js"
],
    source: "dynamic"
});
