(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a2162601._.js",
  "static/chunks/src_components_RevealOnScroll_jsx_ffb1e2cf._.js"
],
    source: "dynamic"
});
