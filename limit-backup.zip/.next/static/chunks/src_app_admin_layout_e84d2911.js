(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_3691ab6e._.js",
  "static/chunks/src_app_admin_Sidebar_jsx_a49d9174._.js"
],
    source: "dynamic"
});
