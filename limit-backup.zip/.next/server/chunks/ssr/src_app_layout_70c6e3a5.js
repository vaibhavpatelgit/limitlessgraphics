module.exports = {

"[project]/src/app/layout.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=src_app_layout_70c6e3a5.js.map