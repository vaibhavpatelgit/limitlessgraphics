module.exports = {

"[project]/src/components/AnimateOnScroll.jsx [app-rsc] (ecmascript, async loader)": ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_components_AnimateOnScroll_jsx_bcadcc5a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/AnimateOnScroll.jsx [app-rsc] (ecmascript)");
    });
});
}),

};